from django.apps import AppConfig


class AuditsConfig(AppConfig):
    name = 'audits'
